import{default as t}from"../components/error.svelte-e3536061.js";export{t as component};
