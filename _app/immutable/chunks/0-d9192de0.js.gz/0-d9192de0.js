import{_ as r}from"./_layout-f9d9eff3.js";import{default as t}from"../components/layout.svelte-1e55e3c3.js";export{t as component,r as shared};
