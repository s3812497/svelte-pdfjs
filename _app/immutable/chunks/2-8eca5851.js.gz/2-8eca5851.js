import{default as t}from"../components/pages/_page.svelte-cdaae548.js";export{t as component};
