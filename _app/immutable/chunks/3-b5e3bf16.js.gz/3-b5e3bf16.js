import{default as t}from"../components/pages/multipage/_page.svelte-5ab1f09d.js";export{t as component};
