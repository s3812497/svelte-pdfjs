import{_ as r}from"./_layout-50971f0e.js";import{default as t}from"../components/layout.svelte-1e55e3c3.js";export{t as component,r as shared};
