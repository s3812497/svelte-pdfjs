import{default as t}from"../components/pages/_page.svelte-eaca39c5.js";export{t as component};
