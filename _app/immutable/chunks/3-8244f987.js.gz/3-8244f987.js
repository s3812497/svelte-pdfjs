import{default as t}from"../components/pages/multipage/_page.svelte-fbe979b1.js";export{t as component};
