import{default as t}from"../components/pages/multipage/_page.svelte-b80f2ed6.js";export{t as component};
