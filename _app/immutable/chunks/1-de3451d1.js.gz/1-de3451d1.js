import{default as t}from"../components/error.svelte-c5af54b6.js";export{t as component};
