import{default as t}from"../components/error.svelte-7e03ccaf.js";export{t as component};
