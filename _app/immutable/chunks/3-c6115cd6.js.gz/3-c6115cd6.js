import{default as t}from"../components/pages/multipage/_page.svelte-66b9d6fb.js";export{t as component};
