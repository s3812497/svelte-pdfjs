import{default as t}from"../components/error.svelte-78954b63.js";export{t as component};
