import{default as t}from"../components/pages/_page.svelte-da47487f.js";export{t as component};
